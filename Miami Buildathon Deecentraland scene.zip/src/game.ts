import { createChannel } from '../node_modules/decentraland-builder-scripts/channel'
import { createInventory } from '../node_modules/decentraland-builder-scripts/inventory'
import Script1 from "../c72c3d45-0309-4834-84df-7b5f517694fa/src/item"
import Script2 from "../683aa047-8043-40f8-8d31-beb7ab1b138c/src/item"
import Script3 from "../846479b0-75d3-450d-bbd6-7e6b3355a7a2/src/item"
import Script4 from "../34bc4fd3-d422-4ffb-b0e5-0fb6a8d0ff8d/src/item"
import Script5 from "../f89ab04f-46ef-42ea-912b-b194eb8d2f02/src/item"
import Script6 from "../d5ee9a47-8484-4824-a609-996298830b51/src/item"
import Script7 from "../4bf77c44-42db-4134-90f0-06da4202ff04/src/item"
import Script8 from "../b853061a-bf5a-4d76-b7f1-92ed9ea4a8bf/src/item"
import Script9 from "../4adfea35-fb5c-4f64-bb5e-c7ebfa350868/src/item"
import Script10 from "../da30258e-3cc1-48a4-bc55-508e923ae977/src/item"
import Script11 from "../6ff6b3aa-083a-4e8c-bdd8-b4d64e1f2db1/src/item"

const _scene = new Entity('_scene')
engine.addEntity(_scene)
const transform = new Transform({
  position: new Vector3(0, 0, 0),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
_scene.addComponentOrReplace(transform)

const mbaTower = new Entity('mbaTower')
engine.addEntity(mbaTower)
mbaTower.setParent(_scene)
const transform2 = new Transform({
  position: new Vector3(18.5, 0, 44.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(0.625, 0.625, 0.625)
})
mbaTower.addComponentOrReplace(transform2)
const gltfShape = new GLTFShape("3054f323-d699-4dfc-9e21-c49e42379dee/MBA tower 14.glb")
gltfShape.withCollisions = true
gltfShape.isPointerBlocker = true
gltfShape.visible = true
mbaTower.addComponentOrReplace(gltfShape)

const verticalBluePad = new Entity('verticalBluePad')
engine.addEntity(verticalBluePad)
verticalBluePad.setParent(_scene)
const transform3 = new Transform({
  position: new Vector3(18, 0, 44.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.5, 1.5, 1.5)
})
verticalBluePad.addComponentOrReplace(transform3)

const verticalBluePad2 = new Entity('verticalBluePad2')
engine.addEntity(verticalBluePad2)
verticalBluePad2.setParent(_scene)
const transform4 = new Transform({
  position: new Vector3(18, 10, 23),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.5, 1.5, 1.5)
})
verticalBluePad2.addComponentOrReplace(transform4)

const verticalBluePad3 = new Entity('verticalBluePad3')
engine.addEntity(verticalBluePad3)
verticalBluePad3.setParent(_scene)
const transform5 = new Transform({
  position: new Vector3(41.6183967590332, 20, 20.784282684326172),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.5, 1.5, 1.5)
})
verticalBluePad3.addComponentOrReplace(transform5)

const verticalBluePad4 = new Entity('verticalBluePad4')
engine.addEntity(verticalBluePad4)
verticalBluePad4.setParent(_scene)
const transform6 = new Transform({
  position: new Vector3(43.18697738647461, 30, 44),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.5, 1.5, 1.5)
})
verticalBluePad4.addComponentOrReplace(transform6)

const toolbox = new Entity('toolbox')
engine.addEntity(toolbox)
toolbox.setParent(_scene)
const transform7 = new Transform({
  position: new Vector3(5, 0, 40),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
toolbox.addComponentOrReplace(transform7)

const arcadeMachineBlue = new Entity('arcadeMachineBlue')
engine.addEntity(arcadeMachineBlue)
arcadeMachineBlue.setParent(_scene)
const transform8 = new Transform({
  position: new Vector3(18, 5, 38.66574478149414),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
arcadeMachineBlue.addComponentOrReplace(transform8)
const gltfShape2 = new GLTFShape("5ff589ff-58c7-44df-a896-5807aad1c9be/Arcade_Machine_Blue.glb")
gltfShape2.withCollisions = true
gltfShape2.isPointerBlocker = true
gltfShape2.visible = true
arcadeMachineBlue.addComponentOrReplace(gltfShape2)

const arcadeMachineRed = new Entity('arcadeMachineRed')
engine.addEntity(arcadeMachineRed)
arcadeMachineRed.setParent(_scene)
const transform9 = new Transform({
  position: new Vector3(18, 15, 17),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
arcadeMachineRed.addComponentOrReplace(transform9)
const gltfShape3 = new GLTFShape("e8c83ae1-6b04-4c19-aa52-113561a90d78/Arcade_Machine_Red.glb")
gltfShape3.withCollisions = true
gltfShape3.isPointerBlocker = true
gltfShape3.visible = true
arcadeMachineRed.addComponentOrReplace(gltfShape3)

const arcadeMachineGreen = new Entity('arcadeMachineGreen')
engine.addEntity(arcadeMachineGreen)
arcadeMachineGreen.setParent(_scene)
const transform10 = new Transform({
  position: new Vector3(41.5, 25, 14.7171049118042),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
arcadeMachineGreen.addComponentOrReplace(transform10)
const gltfShape4 = new GLTFShape("77683fc3-021a-4d5c-8a7a-f6db84b8c819/Arcade_Machine_Green.glb")
gltfShape4.withCollisions = true
gltfShape4.isPointerBlocker = true
gltfShape4.visible = true
arcadeMachineGreen.addComponentOrReplace(gltfShape4)

const clickArea = new Entity('clickArea')
engine.addEntity(clickArea)
clickArea.setParent(_scene)
const transform11 = new Transform({
  position: new Vector3(18, 6, 38.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
clickArea.addComponentOrReplace(transform11)

const clickArea2 = new Entity('clickArea2')
engine.addEntity(clickArea2)
clickArea2.setParent(_scene)
const transform12 = new Transform({
  position: new Vector3(18, 16, 17),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
clickArea2.addComponentOrReplace(transform12)

const clickArea3 = new Entity('clickArea3')
engine.addEntity(clickArea3)
clickArea3.setParent(_scene)
const transform13 = new Transform({
  position: new Vector3(41.5, 26, 14.500001907348633),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
clickArea3.addComponentOrReplace(transform13)

const orangeSpacePod = new Entity('orangeSpacePod')
engine.addEntity(orangeSpacePod)
orangeSpacePod.setParent(_scene)
const transform14 = new Transform({
  position: new Vector3(17.725967407226562, 48, 34.73334884643555),
  rotation: new Quaternion(-6.2364532923975e-15, 1, -1.1920928244535389e-7, -2.2351741790771484e-8),
  scale: new Vector3(6.5000081062316895, 6.5, 6.5000081062316895)
})
orangeSpacePod.addComponentOrReplace(transform14)
const gltfShape5 = new GLTFShape("6914faa3-2f1d-4796-9d47-c5bda933fa52/SpaceShip_01/SpaceShip_01.glb")
gltfShape5.withCollisions = true
gltfShape5.isPointerBlocker = true
gltfShape5.visible = true
orangeSpacePod.addComponentOrReplace(gltfShape5)

const entity = new Entity('entity')
engine.addEntity(entity)
entity.setParent(_scene)
const gltfShape6 = new GLTFShape("d727a55b-158d-4506-b102-e1c963953f9c/FloorBaseSand_01/FloorBaseSand_01.glb")
gltfShape6.withCollisions = true
gltfShape6.isPointerBlocker = true
gltfShape6.visible = true
entity.addComponentOrReplace(gltfShape6)
const transform15 = new Transform({
  position: new Vector3(8, 0, 8),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity.addComponentOrReplace(transform15)

const entity2 = new Entity('entity2')
engine.addEntity(entity2)
entity2.setParent(_scene)
entity2.addComponentOrReplace(gltfShape6)
const transform16 = new Transform({
  position: new Vector3(24, 0, 8),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity2.addComponentOrReplace(transform16)

const entity3 = new Entity('entity3')
engine.addEntity(entity3)
entity3.setParent(_scene)
entity3.addComponentOrReplace(gltfShape6)
const transform17 = new Transform({
  position: new Vector3(40, 0, 8),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity3.addComponentOrReplace(transform17)

const entity4 = new Entity('entity4')
engine.addEntity(entity4)
entity4.setParent(_scene)
entity4.addComponentOrReplace(gltfShape6)
const transform18 = new Transform({
  position: new Vector3(56, 0, 8),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity4.addComponentOrReplace(transform18)

const entity5 = new Entity('entity5')
engine.addEntity(entity5)
entity5.setParent(_scene)
entity5.addComponentOrReplace(gltfShape6)
const transform19 = new Transform({
  position: new Vector3(8, 0, 24),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity5.addComponentOrReplace(transform19)

const entity6 = new Entity('entity6')
engine.addEntity(entity6)
entity6.setParent(_scene)
entity6.addComponentOrReplace(gltfShape6)
const transform20 = new Transform({
  position: new Vector3(24, 0, 24),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity6.addComponentOrReplace(transform20)

const entity7 = new Entity('entity7')
engine.addEntity(entity7)
entity7.setParent(_scene)
entity7.addComponentOrReplace(gltfShape6)
const transform21 = new Transform({
  position: new Vector3(40, 0, 24),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity7.addComponentOrReplace(transform21)

const entity8 = new Entity('entity8')
engine.addEntity(entity8)
entity8.setParent(_scene)
entity8.addComponentOrReplace(gltfShape6)
const transform22 = new Transform({
  position: new Vector3(56, 0, 24),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity8.addComponentOrReplace(transform22)

const entity9 = new Entity('entity9')
engine.addEntity(entity9)
entity9.setParent(_scene)
entity9.addComponentOrReplace(gltfShape6)
const transform23 = new Transform({
  position: new Vector3(8, 0, 40),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity9.addComponentOrReplace(transform23)

const entity10 = new Entity('entity10')
engine.addEntity(entity10)
entity10.setParent(_scene)
entity10.addComponentOrReplace(gltfShape6)
const transform24 = new Transform({
  position: new Vector3(24, 0, 40),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity10.addComponentOrReplace(transform24)

const entity11 = new Entity('entity11')
engine.addEntity(entity11)
entity11.setParent(_scene)
entity11.addComponentOrReplace(gltfShape6)
const transform25 = new Transform({
  position: new Vector3(40, 0, 40),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity11.addComponentOrReplace(transform25)

const entity12 = new Entity('entity12')
engine.addEntity(entity12)
entity12.setParent(_scene)
entity12.addComponentOrReplace(gltfShape6)
const transform26 = new Transform({
  position: new Vector3(56, 0, 40),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity12.addComponentOrReplace(transform26)

const entity13 = new Entity('entity13')
engine.addEntity(entity13)
entity13.setParent(_scene)
entity13.addComponentOrReplace(gltfShape6)
const transform27 = new Transform({
  position: new Vector3(8, 0, 56),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity13.addComponentOrReplace(transform27)

const entity14 = new Entity('entity14')
engine.addEntity(entity14)
entity14.setParent(_scene)
entity14.addComponentOrReplace(gltfShape6)
const transform28 = new Transform({
  position: new Vector3(24, 0, 56),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity14.addComponentOrReplace(transform28)

const entity15 = new Entity('entity15')
engine.addEntity(entity15)
entity15.setParent(_scene)
entity15.addComponentOrReplace(gltfShape6)
const transform29 = new Transform({
  position: new Vector3(40, 0, 56),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity15.addComponentOrReplace(transform29)

const entity16 = new Entity('entity16')
engine.addEntity(entity16)
entity16.setParent(_scene)
entity16.addComponentOrReplace(gltfShape6)
const transform30 = new Transform({
  position: new Vector3(56, 0, 56),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity16.addComponentOrReplace(transform30)

const caribbeanWaterWithTwoSideRocks = new Entity('caribbeanWaterWithTwoSideRocks')
engine.addEntity(caribbeanWaterWithTwoSideRocks)
caribbeanWaterWithTwoSideRocks.setParent(_scene)
const transform31 = new Transform({
  position: new Vector3(34, 0, 28),
  rotation: new Quaternion(-1.5394153601527394e-15, -0.7071068286895752, 8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(4.000006675720215, 4, 4.000006675720215)
})
caribbeanWaterWithTwoSideRocks.addComponentOrReplace(transform31)
const gltfShape7 = new GLTFShape("01d15783-7d05-42d6-a010-3db4b60c63dd/WaterPatchCornerOutside_01/WaterPatchCornerOutside_01.glb")
gltfShape7.withCollisions = true
gltfShape7.isPointerBlocker = true
gltfShape7.visible = true
caribbeanWaterWithTwoSideRocks.addComponentOrReplace(gltfShape7)

const caribbeanWaterWithTwoSideRocks2 = new Entity('caribbeanWaterWithTwoSideRocks2')
engine.addEntity(caribbeanWaterWithTwoSideRocks2)
caribbeanWaterWithTwoSideRocks2.setParent(_scene)
const transform32 = new Transform({
  position: new Vector3(29, 0, 26.5),
  rotation: new Quaternion(-2.360886441245681e-15, 1, -1.1920927533992653e-7, -2.9802318834981634e-8),
  scale: new Vector3(5.000003814697266, 5, 5.000003814697266)
})
caribbeanWaterWithTwoSideRocks2.addComponentOrReplace(transform32)
caribbeanWaterWithTwoSideRocks2.addComponentOrReplace(gltfShape7)

const caribbeanWaterWithTwoSideRocks3 = new Entity('caribbeanWaterWithTwoSideRocks3')
engine.addEntity(caribbeanWaterWithTwoSideRocks3)
caribbeanWaterWithTwoSideRocks3.setParent(_scene)
caribbeanWaterWithTwoSideRocks3.addComponentOrReplace(gltfShape7)
const transform33 = new Transform({
  position: new Vector3(37.5, 0, 26.5),
  rotation: new Quaternion(-1.6693988127768978e-15, 0.7071067690849304, -8.429368847373553e-8, 0.7071068286895752),
  scale: new Vector3(5.000003814697266, 5, 5.000003814697266)
})
caribbeanWaterWithTwoSideRocks3.addComponentOrReplace(transform33)

const caribbeanWaterWithTwoSideRocks4 = new Entity('caribbeanWaterWithTwoSideRocks4')
engine.addEntity(caribbeanWaterWithTwoSideRocks4)
caribbeanWaterWithTwoSideRocks4.setParent(_scene)
caribbeanWaterWithTwoSideRocks4.addComponentOrReplace(gltfShape7)
const transform34 = new Transform({
  position: new Vector3(34, 0, 30),
  rotation: new Quaternion(-2.177062080483132e-15, 0, 1.088531040241566e-15, 1),
  scale: new Vector3(4.000007629394531, 4, 4.000007629394531)
})
caribbeanWaterWithTwoSideRocks4.addComponentOrReplace(transform34)

const rockPillars = new Entity('rockPillars')
engine.addEntity(rockPillars)
rockPillars.setParent(_scene)
const transform35 = new Transform({
  position: new Vector3(40.5, 0, 32),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.924072265625, 1.924072265625, 1.924072265625)
})
rockPillars.addComponentOrReplace(transform35)
const gltfShape8 = new GLTFShape("71b6a344-0d44-409b-b36c-b57068547745/RockPillars_01/RockPillars_01.glb")
gltfShape8.withCollisions = true
gltfShape8.isPointerBlocker = true
gltfShape8.visible = true
rockPillars.addComponentOrReplace(gltfShape8)

const rockPillars2 = new Entity('rockPillars2')
engine.addEntity(rockPillars2)
rockPillars2.setParent(_scene)
rockPillars2.addComponentOrReplace(gltfShape8)
const transform36 = new Transform({
  position: new Vector3(53.62345504760742, 0, 43.32353210449219),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.924072265625, 1.924072265625, 1.924072265625)
})
rockPillars2.addComponentOrReplace(transform36)

const rockPillars3 = new Entity('rockPillars3')
engine.addEntity(rockPillars3)
rockPillars3.setParent(_scene)
rockPillars3.addComponentOrReplace(gltfShape8)
const transform37 = new Transform({
  position: new Vector3(30, 0, 44),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(2.8861083984375, 1.924072265625, 1.924072265625)
})
rockPillars3.addComponentOrReplace(transform37)

const rockPillars4 = new Entity('rockPillars4')
engine.addEntity(rockPillars4)
rockPillars4.setParent(_scene)
rockPillars4.addComponentOrReplace(gltfShape8)
const transform38 = new Transform({
  position: new Vector3(41.5, 0, 10.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.924072265625, 1.924072265625, 1.924072265625)
})
rockPillars4.addComponentOrReplace(transform38)

const rockPillars5 = new Entity('rockPillars5')
engine.addEntity(rockPillars5)
rockPillars5.setParent(_scene)
rockPillars5.addComponentOrReplace(gltfShape8)
const transform39 = new Transform({
  position: new Vector3(29.386613845825195, 0, 23),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.924072265625, 1.924072265625, 1.924072265625)
})
rockPillars5.addComponentOrReplace(transform39)

const turtle = new Entity('turtle')
engine.addEntity(turtle)
turtle.setParent(_scene)
const transform40 = new Transform({
  position: new Vector3(28, 5.5, 40.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.5, 1.5, 1.5)
})
turtle.addComponentOrReplace(transform40)

const turtle2 = new Entity('turtle2')
engine.addEntity(turtle2)
turtle2.setParent(_scene)
const transform41 = new Transform({
  position: new Vector3(32, 5.5, 19),
  rotation: new Quaternion(3.017090065263639e-16, 0.44721442461013794, -5.331210672920861e-8, -0.8944269418716431),
  scale: new Vector3(1.5000004768371582, 1.5, 1.5000004768371582)
})
turtle2.addComponentOrReplace(transform41)

const turtle3 = new Entity('turtle3')
engine.addEntity(turtle3)
turtle3.setParent(_scene)
const transform42 = new Transform({
  position: new Vector3(41, 5.5, 13.5),
  rotation: new Quaternion(-5.336820022635181e-15, -1, 1.1920927533992653e-7, -2.9802318834981634e-8),
  scale: new Vector3(1.5000003576278687, 1.5, 1.5000003576278687)
})
turtle3.addComponentOrReplace(transform42)

const turtle4 = new Entity('turtle4')
engine.addEntity(turtle4)
turtle4.setParent(_scene)
const transform43 = new Transform({
  position: new Vector3(44, 5.5, 34.5),
  rotation: new Quaternion(-8.483292464767783e-15, -0.9238795638084412, 1.1013501222123523e-7, 0.3826834261417389),
  scale: new Vector3(1.5000022649765015, 1.5, 1.5000022649765015)
})
turtle4.addComponentOrReplace(transform43)

const bigSandDune = new Entity('bigSandDune')
engine.addEntity(bigSandDune)
bigSandDune.setParent(_scene)
const transform44 = new Transform({
  position: new Vector3(18, 0, 43),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(2.5, 1, 2.5)
})
bigSandDune.addComponentOrReplace(transform44)
const gltfShape9 = new GLTFShape("76cf13e2-3df0-4eae-af1c-f10ba9acfa33/SandPatchBig_01/SandPatchBig_01.glb")
gltfShape9.withCollisions = true
gltfShape9.isPointerBlocker = true
gltfShape9.visible = true
bigSandDune.addComponentOrReplace(gltfShape9)

const twitterButtonLink = new Entity('twitterButtonLink')
engine.addEntity(twitterButtonLink)
twitterButtonLink.setParent(_scene)
const transform45 = new Transform({
  position: new Vector3(12.8413667678833, 5.613104820251465, 40.1002197265625),
  rotation: new Quaternion(-0.0410488061606884, 0.416775643825531, -0.08900764584541321, 0.9037094712257385),
  scale: new Vector3(1.000000238418579, 0.9999997615814209, 1.000000238418579)
})
twitterButtonLink.addComponentOrReplace(transform45)

const instagramButtonLink = new Entity('instagramButtonLink')
engine.addEntity(instagramButtonLink)
instagramButtonLink.setParent(_scene)
const transform46 = new Transform({
  position: new Vector3(12.57028865814209, 6.642034530639648, 41.15788650512695),
  rotation: new Quaternion(0.00840037316083908, 0.49403244256973267, 0.026486841961741447, 0.8689994215965271),
  scale: new Vector3(1.0000003576278687, 0.9999999403953552, 1)
})
instagramButtonLink.addComponentOrReplace(transform46)

const ballDroid = new Entity('ballDroid')
engine.addEntity(ballDroid)
ballDroid.setParent(_scene)
const transform47 = new Transform({
  position: new Vector3(19.650362014770508, 6.5, 38.69209289550781),
  rotation: new Quaternion(1.2882037050845983e-14, 0.2227880358695984, -2.6558403476428794e-8, -0.9748669862747192),
  scale: new Vector3(1.631958246231079, 1.6319565773010254, 1.631958246231079)
})
ballDroid.addComponentOrReplace(transform47)
const gltfShape10 = new GLTFShape("53a5cc56-9817-4556-a172-bc1a4256610d/Droid_01/Droid_01.glb")
gltfShape10.withCollisions = true
gltfShape10.isPointerBlocker = true
gltfShape10.visible = true
ballDroid.addComponentOrReplace(gltfShape10)

const clickArea4 = new Entity('clickArea4')
engine.addEntity(clickArea4)
clickArea4.setParent(_scene)
const transform48 = new Transform({
  position: new Vector3(19.76848030090332, 6.474334716796875, 38.561927795410156),
  rotation: new Quaternion(2.961364561757167e-16, -0.22565996646881104, 2.6900757177372725e-8, 0.9742061495780945),
  scale: new Vector3(1.586241602897644, 1.58624267578125, 1.586241602897644)
})
clickArea4.addComponentOrReplace(transform48)

const scifiLeverConsole = new Entity('scifiLeverConsole')
engine.addEntity(scifiLeverConsole)
scifiLeverConsole.setParent(_scene)
const transform49 = new Transform({
  position: new Vector3(26.820308685302734, 39.702762603759766, 21.5),
  rotation: new Quaternion(0, -0.2902846932411194, 3.4604628496026635e-8, 0.9569403529167175),
  scale: new Vector3(2, 2, 2)
})
scifiLeverConsole.addComponentOrReplace(transform49)

const poapDispenser = new Entity('poapDispenser')
engine.addEntity(poapDispenser)
poapDispenser.setParent(_scene)
const transform50 = new Transform({
  position: new Vector3(9.79349136352539, 39.650611877441406, 20.97235679626465),
  rotation: new Quaternion(5.496289327427972e-16, 0.25264793634414673, -3.011798099805674e-8, 0.9675582647323608),
  scale: new Vector3(1.2518033981323242, 1.2518033981323242, 1.2518033981323242)
})
poapDispenser.addComponentOrReplace(transform50)
const gltfShape11 = new GLTFShape("17b216cc-5e61-48b1-98fd-22af679ace39/POAP_dispenser.glb")
gltfShape11.withCollisions = true
gltfShape11.isPointerBlocker = true
gltfShape11.visible = true
poapDispenser.addComponentOrReplace(gltfShape11)

const invisibleCylinder = new Entity('invisibleCylinder')
engine.addEntity(invisibleCylinder)
invisibleCylinder.setParent(_scene)
const transform51 = new Transform({
  position: new Vector3(28.999988555908203, 5.5, 22.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(7.364803314208984, 3.682401657104492, 7.364803314208984)
})
invisibleCylinder.addComponentOrReplace(transform51)

const invisibleCylinder2 = new Entity('invisibleCylinder2')
engine.addEntity(invisibleCylinder2)
invisibleCylinder2.setParent(_scene)
const transform52 = new Transform({
  position: new Vector3(41, 5.5, 10),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(7.364803314208984, 3.682401657104492, 7.364803314208984)
})
invisibleCylinder2.addComponentOrReplace(transform52)

const invisibleCylinder3 = new Entity('invisibleCylinder3')
engine.addEntity(invisibleCylinder3)
invisibleCylinder3.setParent(_scene)
const transform53 = new Transform({
  position: new Vector3(40.5, 5.5, 32),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(7.364803314208984, 3.682401657104492, 7.364803314208984)
})
invisibleCylinder3.addComponentOrReplace(transform53)

const invisibleCylinder4 = new Entity('invisibleCylinder4')
engine.addEntity(invisibleCylinder4)
invisibleCylinder4.setParent(_scene)
const transform54 = new Transform({
  position: new Vector3(30.5, 5.5, 43),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(7.364803314208984, 3.682401657104492, 7.364803314208984)
})
invisibleCylinder4.addComponentOrReplace(transform54)

const invisibleCylinder5 = new Entity('invisibleCylinder5')
engine.addEntity(invisibleCylinder5)
invisibleCylinder5.setParent(_scene)
const transform55 = new Transform({
  position: new Vector3(53.5, 5.5, 43),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(7.364803314208984, 3.682401657104492, 7.364803314208984)
})
invisibleCylinder5.addComponentOrReplace(transform55)

const buildathonCoin = new Entity('buildathonCoin')
engine.addEntity(buildathonCoin)
buildathonCoin.setParent(_scene)
const transform56 = new Transform({
  position: new Vector3(41.749977111816406, 7.5, 30),
  rotation: new Quaternion(-0.7231038212776184, 1.5399320502505645e-15, 8.620068570053263e-8, 0.6907394528388977),
  scale: new Vector3(1, 1.000002145767212, 1.000002145767212)
})
buildathonCoin.addComponentOrReplace(transform56)
const gltfShape12 = new GLTFShape("019a9a87-e37c-4a56-9bbb-ea2f5815f319/Buildathon coin.glb")
gltfShape12.withCollisions = true
gltfShape12.isPointerBlocker = true
gltfShape12.visible = true
buildathonCoin.addComponentOrReplace(gltfShape12)

const buildathonCoin2 = new Entity('buildathonCoin2')
engine.addEntity(buildathonCoin2)
buildathonCoin2.setParent(_scene)
buildathonCoin2.addComponentOrReplace(gltfShape12)
const transform57 = new Transform({
  position: new Vector3(31.447830200195312, 7.5, 45.512977600097656),
  rotation: new Quaternion(-0.5589668154716492, 0.4382004737854004, 0.4587321877479553, 0.5339488387107849),
  scale: new Vector3(1.0000003576278687, 1.0000027418136597, 1.0000027418136597)
})
buildathonCoin2.addComponentOrReplace(transform57)

const buildathonCoin3 = new Entity('buildathonCoin3')
engine.addEntity(buildathonCoin3)
buildathonCoin3.setParent(_scene)
buildathonCoin3.addComponentOrReplace(gltfShape12)
const transform58 = new Transform({
  position: new Vector3(30.808101654052734, 7.5, 21.983552932739258),
  rotation: new Quaternion(-0.7231038212776184, 1.5399320502505645e-15, 8.620068570053263e-8, 0.6907394528388977),
  scale: new Vector3(1, 1.0000026226043701, 1.0000026226043701)
})
buildathonCoin3.addComponentOrReplace(transform58)

const buildathonCoin4 = new Entity('buildathonCoin4')
engine.addEntity(buildathonCoin4)
buildathonCoin4.setParent(_scene)
buildathonCoin4.addComponentOrReplace(gltfShape12)
const transform59 = new Transform({
  position: new Vector3(42.58551788330078, 7.5, 11.717838287353516),
  rotation: new Quaternion(-0.7231038212776184, 1.5399320502505645e-15, 8.620068570053263e-8, 0.6907394528388977),
  scale: new Vector3(1, 1.0000038146972656, 1.0000038146972656)
})
buildathonCoin4.addComponentOrReplace(transform59)

const buildathonCoin5 = new Entity('buildathonCoin5')
engine.addEntity(buildathonCoin5)
buildathonCoin5.setParent(_scene)
buildathonCoin5.addComponentOrReplace(gltfShape12)
const transform60 = new Transform({
  position: new Vector3(53.87854766845703, 7.5, 41.456966400146484),
  rotation: new Quaternion(-0.7231038212776184, 1.5399320502505645e-15, 8.620068570053263e-8, 0.6907394528388977),
  scale: new Vector3(1, 1.000004529953003, 1.000004529953003)
})
buildathonCoin5.addComponentOrReplace(transform60)

const clickArea5 = new Entity('clickArea5')
engine.addEntity(clickArea5)
clickArea5.setParent(_scene)
const transform61 = new Transform({
  position: new Vector3(31.5, 7, 45.58613967895508),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
clickArea5.addComponentOrReplace(transform61)

const clickArea6 = new Entity('clickArea6')
engine.addEntity(clickArea6)
clickArea6.setParent(_scene)
const transform62 = new Transform({
  position: new Vector3(30.875856399536133, 7, 22.02689552307129),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
clickArea6.addComponentOrReplace(transform62)

const clickArea7 = new Entity('clickArea7')
engine.addEntity(clickArea7)
clickArea7.setParent(_scene)
const transform63 = new Transform({
  position: new Vector3(42.61397171020508, 7, 11.651803970336914),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
clickArea7.addComponentOrReplace(transform63)

const clickArea8 = new Entity('clickArea8')
engine.addEntity(clickArea8)
clickArea8.setParent(_scene)
const transform64 = new Transform({
  position: new Vector3(41.76963424682617, 7, 29.926897048950195),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
clickArea8.addComponentOrReplace(transform64)

const clickArea9 = new Entity('clickArea9')
engine.addEntity(clickArea9)
clickArea9.setParent(_scene)
const transform65 = new Transform({
  position: new Vector3(53.8695068359375, 7, 41.58134078979492),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
clickArea9.addComponentOrReplace(transform65)

const ballDroid2 = new Entity('ballDroid2')
engine.addEntity(ballDroid2)
ballDroid2.setParent(_scene)
ballDroid2.addComponentOrReplace(gltfShape10)
const transform66 = new Transform({
  position: new Vector3(20.471744537353516, 16.549724578857422, 16.867473602294922),
  rotation: new Quaternion(1.2882037050845983e-14, 0.2227880358695984, -2.6558403476428794e-8, -0.9748669862747192),
  scale: new Vector3(1.631958246231079, 1.6319565773010254, 1.631958246231079)
})
ballDroid2.addComponentOrReplace(transform66)

const ballDroid3 = new Entity('ballDroid3')
engine.addEntity(ballDroid3)
ballDroid3.setParent(_scene)
ballDroid3.addComponentOrReplace(gltfShape10)
const transform67 = new Transform({
  position: new Vector3(43.280879974365234, 26.032453536987305, 14.991511344909668),
  rotation: new Quaternion(-8.92268424165061e-16, -0.1654534786939621, 1.9723593425169383e-8, 0.9862176179885864),
  scale: new Vector3(1.6319572925567627, 1.6319565773010254, 1.6319572925567627)
})
ballDroid3.addComponentOrReplace(transform67)

const ballDroid4 = new Entity('ballDroid4')
engine.addEntity(ballDroid4)
ballDroid4.setParent(_scene)
ballDroid4.addComponentOrReplace(gltfShape10)
const transform68 = new Transform({
  position: new Vector3(42.280879974365234, 36.53245544433594, 48.991512298583984),
  rotation: new Quaternion(4.893514741777802e-15, 0.9995461106300354, -1.191551675105984e-7, -0.03012719936668873),
  scale: new Vector3(1.631957769393921, 1.6319565773010254, 1.631957769393921)
})
ballDroid4.addComponentOrReplace(transform68)

const arcadeMachineBlack = new Entity('arcadeMachineBlack')
engine.addEntity(arcadeMachineBlack)
arcadeMachineBlack.setParent(_scene)
const transform69 = new Transform({
  position: new Vector3(44.3387336730957, 34.6314697265625, 49.163185119628906),
  rotation: new Quaternion(-1.4325316342007286e-16, -0.9974756836891174, 1.1890836049133213e-7, 0.07101006805896759),
  scale: new Vector3(1.5000052452087402, 1.5, 1.5000052452087402)
})
arcadeMachineBlack.addComponentOrReplace(transform69)
const gltfShape13 = new GLTFShape("7dc89fda-c062-4bf2-aa97-7d6748c8d2f4/Arcade_Machine_Black.glb")
gltfShape13.withCollisions = true
gltfShape13.isPointerBlocker = true
gltfShape13.visible = true
arcadeMachineBlack.addComponentOrReplace(gltfShape13)

const clickArea10 = new Entity('clickArea10')
engine.addEntity(clickArea10)
clickArea10.setParent(_scene)
const transform70 = new Transform({
  position: new Vector3(20.52058219909668, 16.498674392700195, 16.72956085205078),
  rotation: new Quaternion(2.961364561757167e-16, -0.22565996646881104, 2.6900757177372725e-8, 0.9742061495780945),
  scale: new Vector3(1.586241602897644, 1.58624267578125, 1.586241602897644)
})
clickArea10.addComponentOrReplace(transform70)

const clickArea11 = new Entity('clickArea11')
engine.addEntity(clickArea11)
clickArea11.setParent(_scene)
const transform71 = new Transform({
  position: new Vector3(43.385196685791016, 26.062442779541016, 14.903969764709473),
  rotation: new Quaternion(2.961364561757167e-16, -0.22565996646881104, 2.6900757177372725e-8, 0.9742061495780945),
  scale: new Vector3(1.586241602897644, 1.58624267578125, 1.586241602897644)
})
clickArea11.addComponentOrReplace(transform71)

const clickArea12 = new Entity('clickArea12')
engine.addEntity(clickArea12)
clickArea12.setParent(_scene)
const transform72 = new Transform({
  position: new Vector3(42.29585266113281, 36.43564987182617, 48.877689361572266),
  rotation: new Quaternion(2.961364561757167e-16, -0.22565996646881104, 2.6900757177372725e-8, 0.9742061495780945),
  scale: new Vector3(1.586241602897644, 1.58624267578125, 1.586241602897644)
})
clickArea12.addComponentOrReplace(transform72)

const clickArea13 = new Entity('clickArea13')
engine.addEntity(clickArea13)
clickArea13.setParent(_scene)
const transform73 = new Transform({
  position: new Vector3(44.29863739013672, 36.59972381591797, 48.96500015258789),
  rotation: new Quaternion(7.37256484673408e-18, 0.0732637271285057, -8.733715972653044e-9, 0.997312605381012),
  scale: new Vector3(0.9999999403953552, 1, 0.9999999403953552)
})
clickArea13.addComponentOrReplace(transform73)

const mixtable = new Entity('mixtable')
engine.addEntity(mixtable)
mixtable.setParent(_scene)
const transform74 = new Transform({
  position: new Vector3(8.74924373626709, 39.62075424194336, 31.49523162841797),
  rotation: new Quaternion(2.1227547748281592e-15, 0.6860002875328064, -8.177760690841751e-8, -0.7276012897491455),
  scale: new Vector3(1.000001311302185, 1, 1.000001311302185)
})
mixtable.addComponentOrReplace(transform74)

const speakers = new Entity('speakers')
engine.addEntity(speakers)
speakers.setParent(_scene)
const transform75 = new Transform({
  position: new Vector3(10.207574844360352, 39.605167388916016, 26.968658447265625),
  rotation: new Quaternion(1.5203487543891635e-15, -0.7071067690849304, 8.429368847373553e-8, -0.7071068286895752),
  scale: new Vector3(1.5476081371307373, 1.5476081371307373, 1.5476081371307373)
})
speakers.addComponentOrReplace(transform75)

const speakers2 = new Entity('speakers2')
engine.addEntity(speakers2)
speakers2.setParent(_scene)
const transform76 = new Transform({
  position: new Vector3(10, 39.605167388916016, 35.73814392089844),
  rotation: new Quaternion(1.5203487543891635e-15, -0.7071067690849304, 8.429368847373553e-8, -0.7071068286895752),
  scale: new Vector3(1.5476081371307373, 1.5476081371307373, 1.5476081371307373)
})
speakers2.addComponentOrReplace(transform76)

const invisibleCylinder6 = new Entity('invisibleCylinder6')
engine.addEntity(invisibleCylinder6)
invisibleCylinder6.setParent(_scene)
const transform77 = new Transform({
  position: new Vector3(32, 0, 32),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
invisibleCylinder6.addComponentOrReplace(transform77)

const invisibleCylinder7 = new Entity('invisibleCylinder7')
engine.addEntity(invisibleCylinder7)
invisibleCylinder7.setParent(_scene)
const transform78 = new Transform({
  position: new Vector3(18.4237003326416, 9.476439476013184, 22.94696044921875),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(6.024259567260742, 5.3768768310546875, 6.024259567260742)
})
invisibleCylinder7.addComponentOrReplace(transform78)

const invisibleCylinder8 = new Entity('invisibleCylinder8')
engine.addEntity(invisibleCylinder8)
invisibleCylinder8.setParent(_scene)
const transform79 = new Transform({
  position: new Vector3(41.882606506347656, 19.298450469970703, 20.739768981933594),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(6.024259567260742, 5.3768768310546875, 6.024259567260742)
})
invisibleCylinder8.addComponentOrReplace(transform79)

const invisibleCylinder9 = new Entity('invisibleCylinder9')
engine.addEntity(invisibleCylinder9)
invisibleCylinder9.setParent(_scene)
const transform80 = new Transform({
  position: new Vector3(43.23346710205078, 29.298450469970703, 43.9286994934082),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(6.024259567260742, 5.3768768310546875, 6.024259567260742)
})
invisibleCylinder9.addComponentOrReplace(transform80)

const invisibleWall = new Entity('invisibleWall')
engine.addEntity(invisibleWall)
invisibleWall.setParent(_scene)
const transform81 = new Transform({
  position: new Vector3(28.430185317993164, 39.765235900878906, 46.20696258544922),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(2.5, 7.5, 3.9498860836029053)
})
invisibleWall.addComponentOrReplace(transform81)

const clickArea14 = new Entity('clickArea14')
engine.addEntity(clickArea14)
clickArea14.setParent(_scene)
const transform82 = new Transform({
  position: new Vector3(10.028084754943848, 39.81919479370117, 21.310338973999023),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 2.8583221435546875, 1)
})
clickArea14.addComponentOrReplace(transform82)

const buildathonHoodie = new Entity('buildathonHoodie')
engine.addEntity(buildathonHoodie)
buildathonHoodie.setParent(_scene)
const transform83 = new Transform({
  position: new Vector3(18.000019073486328, 36.99081802368164, 20.611629486083984),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(3.3322677612304688, 3.3322677612304688, 3.3322677612304688)
})
buildathonHoodie.addComponentOrReplace(transform83)
const gltfShape14 = new GLTFShape("7f463a85-4a16-4dce-ba3b-5af697466aee/Buildathon hoodie.glb")
gltfShape14.withCollisions = true
gltfShape14.isPointerBlocker = true
gltfShape14.visible = true
buildathonHoodie.addComponentOrReplace(gltfShape14)

const clickArea15 = new Entity('clickArea15')
engine.addEntity(clickArea15)
clickArea15.setParent(_scene)
const transform84 = new Transform({
  position: new Vector3(18.028085708618164, 39.81919479370117, 20.797618865966797),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.9127252101898193, 2.8583221435546875, 1)
})
clickArea15.addComponentOrReplace(transform84)

const channelId = Math.random().toString(16).slice(2)
const channelBus = new MessageBus()
const inventory = createInventory(UICanvas, UIContainerStack, UIImage)
const options = { inventory }

const script1 = new Script1()
const script2 = new Script2()
const script3 = new Script3()
const script4 = new Script4()
const script5 = new Script5()
const script6 = new Script6()
const script7 = new Script7()
const script8 = new Script8()
const script9 = new Script9()
const script10 = new Script10()
const script11 = new Script11()
script1.init(options)
script2.init(options)
script3.init(options)
script4.init(options)
script5.init(options)
script6.init(options)
script7.init(options)
script8.init(options)
script9.init(options)
script10.init(options)
script11.init(options)
script1.spawn(verticalBluePad, {"distance":7,"speed":5,"autoStart":true,"onReachEnd":[{"entityName":"verticalBluePad","actionId":"goToStart","values":{}}],"onReachStart":[{"entityName":"verticalBluePad","actionId":"goToEnd","values":{}}]}, createChannel(channelId, verticalBluePad, channelBus))
script1.spawn(verticalBluePad2, {"distance":7,"speed":5,"autoStart":true,"onReachEnd":[{"entityName":"verticalBluePad2","actionId":"goToStart","values":{}}],"onReachStart":[{"entityName":"verticalBluePad2","actionId":"goToEnd","values":{}}]}, createChannel(channelId, verticalBluePad2, channelBus))
script1.spawn(verticalBluePad3, {"distance":7,"speed":5,"autoStart":true,"onReachEnd":[{"entityName":"verticalBluePad3","actionId":"goToStart","values":{}}],"onReachStart":[{"entityName":"verticalBluePad3","actionId":"goToEnd","values":{}}]}, createChannel(channelId, verticalBluePad3, channelBus))
script1.spawn(verticalBluePad4, {"distance":7,"speed":5,"autoStart":true,"onReachEnd":[{"entityName":"verticalBluePad4","actionId":"goToStart","values":{}}],"onReachStart":[{"entityName":"verticalBluePad4","actionId":"goToEnd","values":{}}]}, createChannel(channelId, verticalBluePad4, channelBus))
script2.spawn(toolbox, {}, createChannel(channelId, toolbox, channelBus))
script3.spawn(clickArea, {"enabled":true,"onClickText":"Check-in","button":"POINTER","onClick":[{"entityName":"toolbox","actionId":"move","values":{"target":"invisibleCylinder7","x":0,"y":-10,"z":0,"curve":"linear","speed":10,"relative":true,"onComplete":[]}}]}, createChannel(channelId, clickArea, channelBus))
script3.spawn(clickArea2, {"enabled":true,"onClickText":"Select  Workshop","button":"POINTER","onClick":[{"entityName":"toolbox","actionId":"move","values":{"target":"invisibleCylinder8","x":0,"y":-10,"z":0,"curve":"linear","speed":10,"relative":true,"onComplete":[]}}]}, createChannel(channelId, clickArea2, channelBus))
script3.spawn(clickArea3, {"enabled":true,"onClickText":"Pick your team","button":"POINTER","onClick":[{"entityName":"toolbox","actionId":"move","values":{"target":"invisibleCylinder9","x":0,"y":-10,"z":0,"curve":"linear","speed":10,"relative":true,"onComplete":[]}}]}, createChannel(channelId, clickArea3, channelBus))
script4.spawn(turtle, {"distance":10,"speed":3,"autoStart":true,"onReachEnd":[{"entityName":"turtle","actionId":"goToStart","values":{}}],"onReachStart":[{"entityName":"turtle","actionId":"goToEnd","values":{}}]}, createChannel(channelId, turtle, channelBus))
script4.spawn(turtle2, {"distance":7,"speed":3,"autoStart":true,"onReachEnd":[{"entityName":"turtle2","actionId":"goToStart","values":{}}],"onReachStart":[{"entityName":"turtle2","actionId":"goToEnd","values":{}}]}, createChannel(channelId, turtle2, channelBus))
script4.spawn(turtle3, {"distance":8,"speed":3,"autoStart":true,"onReachEnd":[{"entityName":"turtle3","actionId":"goToStart","values":{}}],"onReachStart":[{"entityName":"turtle3","actionId":"goToEnd","values":{}}]}, createChannel(channelId, turtle3, channelBus))
script4.spawn(turtle4, {"distance":6,"speed":3,"autoStart":true,"onReachEnd":[{"entityName":"turtle4","actionId":"goToStart","values":{}}],"onReachStart":[{"entityName":"turtle4","actionId":"goToEnd","values":{}}]}, createChannel(channelId, turtle4, channelBus))
script5.spawn(twitterButtonLink, {"url":"decentraland","bnw":false}, createChannel(channelId, twitterButtonLink, channelBus))
script6.spawn(instagramButtonLink, {"url":"decentraland_art","bnw":false}, createChannel(channelId, instagramButtonLink, channelBus))
script3.spawn(clickArea4, {"enabled":true,"onClickText":"Step 1","button":"POINTER","onClick":[{"entityName":"toolbox","actionId":"print","values":{"message":"Welcome to the Miami NFT Buildathon. I see you are a registerd builder click the machine to check-in and move on to the Workshop tower.","duration":5,"multiplayer":false}}]}, createChannel(channelId, clickArea4, channelBus))
script7.spawn(scifiLeverConsole, {"onActivate":[{"entityName":"toolbox","actionId":"move","values":{"x":0,"y":-10,"z":0,"curve":"linear","speed":10,"relative":true,"onComplete":[],"target":"invisibleCylinder"}},{"entityName":"toolbox","actionId":"move","values":{"target":"invisibleCylinder2","x":0,"y":-10,"z":0,"curve":"linear","speed":10,"relative":true,"onComplete":[]}},{"entityName":"toolbox","actionId":"move","values":{"target":"invisibleCylinder3","x":0,"y":-10,"z":0,"curve":"linear","speed":10,"relative":true,"onComplete":[]}},{"entityName":"toolbox","actionId":"move","values":{"target":"invisibleCylinder4","x":0,"y":-10,"z":0,"curve":"linear","speed":10,"relative":true,"onComplete":[]}},{"entityName":"toolbox","actionId":"move","values":{"target":"invisibleCylinder5","x":0,"y":-10,"z":0,"curve":"linear","speed":10,"relative":true,"onComplete":[]}}]}, createChannel(channelId, scifiLeverConsole, channelBus))
script8.spawn(invisibleCylinder, {"enabled":true}, createChannel(channelId, invisibleCylinder, channelBus))
script8.spawn(invisibleCylinder2, {"enabled":true}, createChannel(channelId, invisibleCylinder2, channelBus))
script8.spawn(invisibleCylinder3, {"enabled":true}, createChannel(channelId, invisibleCylinder3, channelBus))
script8.spawn(invisibleCylinder4, {"enabled":true}, createChannel(channelId, invisibleCylinder4, channelBus))
script8.spawn(invisibleCylinder5, {"enabled":false}, createChannel(channelId, invisibleCylinder5, channelBus))
script3.spawn(clickArea5, {"enabled":true,"onClickText":"Interact","button":"POINTER","onClick":[{"entityName":"toolbox","actionId":"move","values":{"target":"buildathonCoin2","x":0,"y":-20,"z":0,"curve":"linear","speed":10,"relative":true,"onComplete":[]}},{"entityName":"toolbox","actionId":"print","values":{"message":"4 More To Go","duration":5,"multiplayer":false}}]}, createChannel(channelId, clickArea5, channelBus))
script3.spawn(clickArea6, {"enabled":true,"onClickText":"Interact","button":"POINTER","onClick":[{"entityName":"toolbox","actionId":"move","values":{"target":"buildathonCoin3","x":0,"y":-20,"z":0,"curve":"linear","speed":10,"relative":true,"onComplete":[]}},{"entityName":"toolbox","actionId":"print","values":{"message":"3 More To Go","duration":5,"multiplayer":false}}]}, createChannel(channelId, clickArea6, channelBus))
script3.spawn(clickArea7, {"enabled":true,"onClickText":"Interact","button":"POINTER","onClick":[{"entityName":"toolbox","actionId":"move","values":{"target":"buildathonCoin4","x":0,"y":-20,"z":0,"curve":"linear","speed":10,"relative":true,"onComplete":[]}},{"entityName":"toolbox","actionId":"print","values":{"message":"2 More To Go","duration":5,"multiplayer":false}}]}, createChannel(channelId, clickArea7, channelBus))
script3.spawn(clickArea8, {"enabled":true,"onClickText":"Interact","button":"POINTER","onClick":[{"entityName":"toolbox","actionId":"move","values":{"target":"buildathonCoin","x":0,"y":-20,"z":0,"curve":"linear","speed":10,"relative":true,"onComplete":[]}},{"entityName":"toolbox","actionId":"print","values":{"message":"1 More To Go","duration":5,"multiplayer":false}}]}, createChannel(channelId, clickArea8, channelBus))
script3.spawn(clickArea9, {"enabled":true,"onClickText":"Interact","button":"POINTER","onClick":[{"entityName":"toolbox","actionId":"move","values":{"target":"buildathonCoin5","x":0,"y":-20,"z":0,"curve":"linear","speed":10,"relative":true,"onComplete":[]}},{"entityName":"toolbox","actionId":"print","values":{"message":"Great Job! Return to the Club to collect your Prize.","duration":5,"multiplayer":false}},{"entityName":"toolbox","actionId":"move","values":{"target":"clickArea14","x":0,"y":-15,"z":0,"curve":"linear","speed":10,"relative":true,"onComplete":[]}}]}, createChannel(channelId, clickArea9, channelBus))
script3.spawn(clickArea10, {"enabled":true,"onClickText":"Step 2","button":"POINTER","onClick":[{"entityName":"toolbox","actionId":"print","values":{"message":"Glad you made it. Here in the workshop\n you can learn about the different paths\n Creative, No-Code, Technical and Sponsor challenges. \nOnce you're ready active the\n machine to move on to the team\n creation tower.","duration":10,"multiplayer":false}}]}, createChannel(channelId, clickArea10, channelBus))
script3.spawn(clickArea11, {"enabled":true,"onClickText":"Step 3","button":"POINTER","onClick":[{"entityName":"toolbox","actionId":"print","values":{"message":"Now that you have your team, active the machine to move on to the judging tower.","duration":5,"multiplayer":false}}]}, createChannel(channelId, clickArea11, channelBus))
script3.spawn(clickArea12, {"enabled":true,"onClickText":"Final Step","button":"POINTER","onClick":[{"entityName":"toolbox","actionId":"print","values":{"message":"Congratulations! You and your team \nhave shown true creativity and skill in\n your project. \n You are the winners of the \nMiami NFT Buidathon.  \nWhat are you waiting for, \nactivate the machine and go celebrate.","duration":10,"multiplayer":false}}]}, createChannel(channelId, clickArea12, channelBus))
script3.spawn(clickArea13, {"enabled":true,"onClickText":"Let's Party! Click the lever in the club to active sidequest.","button":"POINTER","onClick":[{"entityName":"toolbox","actionId":"move","values":{"target":"invisibleWall","x":0,"y":-30,"z":0,"curve":"linear","speed":10,"relative":true,"onComplete":[]}}]}, createChannel(channelId, clickArea13, channelBus))
script9.spawn(mixtable, {}, createChannel(channelId, mixtable, channelBus))
script10.spawn(speakers, {"clickable":true}, createChannel(channelId, speakers, channelBus))
script10.spawn(speakers2, {"clickable":true}, createChannel(channelId, speakers2, channelBus))
script8.spawn(invisibleCylinder6, {"enabled":true}, createChannel(channelId, invisibleCylinder6, channelBus))
script8.spawn(invisibleCylinder7, {"enabled":true}, createChannel(channelId, invisibleCylinder7, channelBus))
script8.spawn(invisibleCylinder8, {"enabled":true}, createChannel(channelId, invisibleCylinder8, channelBus))
script8.spawn(invisibleCylinder9, {"enabled":true}, createChannel(channelId, invisibleCylinder9, channelBus))
script11.spawn(invisibleWall, {"enabled":true}, createChannel(channelId, invisibleWall, channelBus))
script3.spawn(clickArea14, {"enabled":true,"onClickText":"Sidequest","button":"POINTER","onClick":[{"entityName":"toolbox","actionId":"print","values":{"message":"Collect 5 Buildathon coins to claim your POAP. Use the lever on the left to \nactivate the sidequest.","duration":5,"multiplayer":false}}]}, createChannel(channelId, clickArea14, channelBus))
script3.spawn(clickArea15, {"enabled":true,"onClickText":"Sidequest","button":"POINTER","onClick":[{"entityName":"toolbox","actionId":"print","values":{"message":"Collect 5 Buildathon coins to claim your wearable. Use the lever on the left to \nactivate the sidequest.","duration":5,"multiplayer":false}}]}, createChannel(channelId, clickArea15, channelBus))